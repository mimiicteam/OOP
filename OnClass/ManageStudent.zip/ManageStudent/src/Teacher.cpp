#include "Teacher.h"

Teacher::Teacher()
{
    //ctor
}

Teacher::~Teacher()
{
    //dtor
}
