#include <iostream>
#include "Date.h"
using namespace std;

int main()
{
//    Student st1;
//    cin>>st1;
//    cout<<st1;
    Date d1;
    cin>>d1;

}
